#pragma once
#include "../Number/Number.h"

class Vector {
    private : 
    Number x;
    Number y;

    public:
     Vector();
     Vector(const Number& x_val, const Number& y_val);

     Number getX() const;
     Number getY() const;
     Number getRadius() const;
     Number getAngle() const;

     Vector operator+(const Vector& other) const;

};

extern Vector ZERO_VECTOR;
extern Vector ONE_VECTOR;