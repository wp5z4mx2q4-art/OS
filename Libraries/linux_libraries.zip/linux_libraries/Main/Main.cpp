#include <iostream>
#include "../Number/Number.h"
#include "../Vector/Vector.h"

using namespace std;

int main(){
    cout << " Number (static)" << endl;

    Number a = createNumber(8.0);
    Number b = createNumber(2.0);
    
    cout << "a= " << a.getValue() << endl;
    cout << "b= " << b.getValue() << endl;
    cout << "a+b = " << (a+b).getValue()<< endl;
    cout << "a-b = " << (a-b).getValue()<< endl;
    cout << "a*b= " << (a*b).getValue()<< endl;
    cout << "a/b= " << (a/b).getValue()<<endl;

    cout << "Zero"<< ZERO.getValue()<< endl;
    cout << "One"<< ONE.getValue()<< endl;



    cout << "Vector (dynamic)" << endl;

    Vector v1(createNumber(3.0), createNumber(4.0));
    Vector v2(createNumber(1.0), createNumber(2.0));

    cout << "Vector v1: (" << v1.getX().getValue()<<","<< v1.getY().getValue() << ")"<< endl;
    cout << "Vector v2: (" << v2.getX().getValue()<<","<< v2.getY().getValue() << ")"<< endl;

    Vector v3= v1 +v2;
    cout << "v1+v2 = (" << v3.getX().getValue()<< ","<< v3.getY().getValue() << ")" << endl;

    cout << "v1 radius" << v1.getRadius().getValue()<< endl;
    cout << "v1 angle: " << v1.getAngle().getValue() << "radians" << endl;

    cout << "0v : (" << ZERO_VECTOR.getX().getValue()<< ","<< ZERO_VECTOR.getY().getValue() << ")" << endl;
    cout << "1v : (" << ONE_VECTOR.getX().getValue()<< ","<< ONE_VECTOR.getY().getValue() << ")" << endl;

    return 0;

}