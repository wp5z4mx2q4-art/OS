#pragma once
class Number {
    private :
    double value;

    public :
    Number();
    Number (double val);

    Number operator+(const Number& other) const;
    Number operator-(const Number& other) const;
    Number operator*(const Number& other) const;
    Number operator/(const Number& other) const;

    double getValue() const;
    void setValue (double val);
};

extern Number ZERO;
extern Number ONE;

Number createNumber(double value);